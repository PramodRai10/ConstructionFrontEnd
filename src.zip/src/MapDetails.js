const UserDetails=[
{

    status:"Successful",
    companyname:" ABC Company",
    address:"D/134,kalyanpur,Lucknow",
    DateOfSubmissoin:"Submitted on :- 12-5-2020",
   
},

{
    status:"Successful",
    companyname:"XYZ Company",
    address:"Rajiv Nagar,Delhi",
    DateOfSubmissoin:"Submitted on :- 1-8-2020",
    
},

{
    status:"Successful",
    companyname:"HBC Company",
    address:"Sector-6,Noida",
    DateOfSubmissoin:" Submitted on :- 2-9-2020",
    

}



];
export default UserDetails;